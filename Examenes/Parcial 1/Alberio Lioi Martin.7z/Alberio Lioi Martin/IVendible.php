<?php
    interface IVendible
    {
        public function PrecioMasIva();
    }

?>